using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Utilities")]
[assembly: AssemblyDescription("Utilities")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("ٱللَّهُمَّ صَلِّ عَلَىٰ مُحَمَّدٍ وَءَالِ مُحَمَّدٍ")]
[assembly: AssemblyProduct("QuranCode")]
[assembly: AssemblyCopyright("©2009-2018 Ali Adams - علي عبد الرزاق عبد الكريم القره غولي")]
[assembly: AssemblyTrademark("http://qurancode.com/")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("d159d831-354d-46ab-a3ee-9de81b30bf0e")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.0.*")]
[assembly: AssemblyVersion("6.19.777.4")]
[assembly: AssemblyFileVersion("6.19.777.4")]
