These flag icons have been created by Yummygum. You can use these anywhere you like without attribution. Re-distribution and sale of these icons is not allowed. However, spreading the word is much appreciated. Enjoy the icons! 

––––––––
WEB
www.yummygum.com

––––––––
TWITTER
@yummygum

––––––––
DRIBBBLE
yummygum

––––
LIST OF FLAGS IN SET

Afghanistan
Albania
Algeria
Andorra
Angola
Antarctica
Antigua and Barbuda
Argentina
Armenia
Aruba
Australia
Azerbaijan
The Bahamas
Bahrain
Bangladesh
Barbados
Belarus
Belgium
Belize
Benin
Bhutan
Bosnia and Herzegovina
Botswana
Brazil
Brunei
Burkina Faso
Cambodia
Cameroon
Canada
Cape Verde
Chad
Chile
China
Colombia
Congo
Côte d'Ivoire (Ivory Coast)
Costa Rica
Croatia
Cuba
Cyrus
Czech Republic
Denmark
Dominican Republic
Ecuador
Egypt
El Salvador
Estonia
Ethiopia
European Union
Finland
France
Gabon
Gambia
Georgia
Germany
Ghana
Greece
Guatamala
Guinea
Guinea Bissau
Guyana
Honduras
Hungary
Hong Kong
Iceland
India
Indonesia
Iran
Iraq
Ireland
Israel
Italy
Jamaica
Japan
Jordan
North Korea
South Korea
Latvia
Lebanon
Liberia
Luxembourg
Mexico
Montenegro
Morocco
Mozambique
The Netherlands
New Zealand
Nicaragua
Niger
Nigeria
Norway
Pakistan
Palestine
Paraguay
Peru
Philippines
Poland
Portugal
Puerto Rico
Romania
Russia
Rwanda
Saudi Arabia
Scotland
Senegal
Serbia
Sierra Leone
Singapore
Slovenia
Slovakia
Somalia
South Africa
Spain
Sudan
Suriname
Sweden
Switzerland
Syria
Taiwan
Tanzania
Thailand
Togo
Trinidad and Tobago
Tunisia
Turkey
United Arab Emirates
United Kingdom
Uruguay
Ukraine
Usa
Venezuela
Vietnam
Wales
Yemen
Zambia
Zimbabwe
Nasa World Flag
Rainbow Flag

