using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("InitialLetters")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("http://github.com/offby1/anagrams")]
[assembly: AssemblyProduct("Initial Letters")]
[assembly: AssemblyCopyright("©2007 OffBy1 and ©2012 Ali Adams - علي عبد الرزاق عبد الكريم القره غولي")]
[assembly: AssemblyTrademark("http://qurancode.com")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("24e5533e-da0b-4c40-baa3-d73fb1c4f269")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
[assembly: AssemblyVersion("6.19.751.4")]
[assembly: AssemblyFileVersion("6.19.751.4")]
