using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("WAVMaker")]
[assembly: AssemblyDescription("Make WAV Files from Integer Array")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Eric Oulashin")]
[assembly: AssemblyProduct("WAVMaker")]
[assembly: AssemblyCopyright("Copyright ©2009 Eric Oulashin")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("ca3449bb-ec6a-4974-8832-c673a9e62e2e")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("7.29.139.*")]
[assembly: AssemblyVersion("7.29.139.*")]
[assembly: AssemblyFileVersion("7.29.139.8317")]
