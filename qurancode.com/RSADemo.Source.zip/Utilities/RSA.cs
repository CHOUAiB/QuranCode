﻿using System;
using System.Collections.Generic;
using System.Text;

public class RSA
{
    // ASCII table
    private static char[] s_conversion_table = {
        ' ', '!', '\"', '#', '$', '%', '&', '?', '(', ')',
        '*', '+', ',', '-', '.', '/', '0', '1', '2', '3',
        '4', '5', '6', '7', '8', '9', ':', ';', '<', '=',
        '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G',
        'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
        'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[',
        '\\', ']', '^', '_', '`', 'a', 'b', 'c', 'd', 'e',
        'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
        'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y',
        'z', '{', '|', '}', '~', '\'', '±', '∞', 'º' //only upto 98 char
        // because we need to shift all char forward to 01 to 99 range
        // because 00 is useless on left side of values (0065 same as 65)
    };

    public const int CHAR_DIGITS = 2; // from 00 to 98
    public const int CHAR_SHIFT = 1;  // to 01 to 99 to avoid 0

    private static BigInteger s_p;    // large prime
    private static BigInteger s_q;    // large prime
    private static BigInteger s_n;    // p * q              [public divisor]
    private static BigInteger s_r;    // (p-1) * (q-1)      [number of mod n remainder coprime to n]
    private static BigInteger s_e;    // e is coprime to r  [public key together with n]
    private static BigInteger s_x;    // e*x - r*y = 1      [private key together with n, destroy p, q, r, y]
    private static BigInteger s_y;    // e*x - r*y = 1      [x = (1 + r*y)/e  so  C = M^(e*x) = M^(1 + r*y) = M^1 * M^(r*y) = M * (M^y)^r which is == M (mod n)]
    private static BigInteger s_m;    // original message   [plaintext]
    private static BigInteger s_c;    // encrypted message  [ciphertext]
    private static BigInteger s_dm;   // decrypted message  [plaintext]

    public static BigInteger P
    {
        get { return s_p; }
        set { s_p = value; }
    }
    public static BigInteger Q
    {
        get { return s_q; }
        set { s_q = value; }
    }
    public static BigInteger N
    {
        get { return s_n; }
        set { s_n = value; }
    }
    public static BigInteger R
    {
        get { return s_r; }
        set { s_r = value; }
    }
    public static BigInteger E
    {
        get { return s_e; }
        set { s_e = value; }
    }
    public static BigInteger X
    {
        get { return s_x; }
        set { s_x = value; }
    }
    public static BigInteger Y
    {
        get { return s_y; }
        set { s_y = value; }
    }
    public static BigInteger M
    {
        get { return s_m; }
        set { s_m = value; }
    }
    public static BigInteger C
    {
        get { return s_c; }
        set { s_c = value; }
    }
    public static BigInteger dM
    {
        get { return s_dm; }
        set { s_dm = value; }
    }

    private static bool s_keys_are_setup;
    public static bool KeysAreSetup
    {
        get { return s_keys_are_setup; }
    }

    public static bool SetupKeys(string pString, string qString)
    {
        s_keys_are_setup = false;

        if (String.IsNullOrEmpty(pString)) return false;
        if (String.IsNullOrEmpty(qString)) return false;

        try
        {
            P = new BigInteger(pString, 10);
        }
        catch (Exception ex)
        {
            return false;
        }

        try
        {
            Q = new BigInteger(qString, 10);
        }
        catch (Exception ex)
        {
            return false;
        }

        N = P * Q;

        R = (P - 1) * (Q - 1);

        try
        {
            E = R.genCoPrime(R.bitCount(), new Random());
        }
        catch (Exception ex)
        {
            throw new Exception("cannot find e coprime to r");
        }

        // choose x and y that satisfy e*x - r*y = 1
        try
        {
            X = 1;
            Y = 1;
            while (((E * X) - (R * Y)) != 1)
            {
                X++;
                Y = ((E * X) - 1) / R;
                if (X > N)
                {
                    // choose a different e
                    E = R.genCoPrime(R.bitCount(), new Random());

                    // restart seach for suitable x and y
                    X = 1;
                    Y = 1;
                }
            }
        }
        catch (Exception ex)
        {
            throw new Exception("cannot find x and y that satisfy" + "\r\n" + "e*x - r*y = 1");
        }

        s_keys_are_setup = true;
        return s_keys_are_setup;
    }

    public static string Encrypt(string message)
    {
        if (!s_keys_are_setup) return "No keys are setup";

        if (String.IsNullOrEmpty(message)) return "No plaintext";

        string ciphervalue = "";
        try
        {
            // build plainvalue from plaintext
            StringBuilder plainvalue = new StringBuilder();
            for (int i = 0; i < message.Length; i++)
            {
                for (int j = 0; j < s_conversion_table.Length; j++)
                {
                    if (message[i] == s_conversion_table[j])
                    {
                        string j_str = (j + CHAR_SHIFT).ToString();
                        // left-pad with 0 if needed
                        if ((j_str.Length % CHAR_DIGITS) != 0)
                        {
                            j_str = "0" + j_str;
                        }
                        plainvalue.Append(j_str);
                        break;
                    }
                }
            }
            M = new BigInteger(plainvalue.ToString(), 10);

            // generate ciphevalue from plainvalue
            C = M.modPow(E, N);
            ciphervalue = C.ToString();
            // left-pad with 0 if needed
            if ((ciphervalue.Length % CHAR_DIGITS) != 0)
            {
                ciphervalue = "0" + ciphervalue;
            }
        }
        catch (Exception ex)
        {
            // not supported char in message
            throw ex;
        }
        return ciphervalue;
    }

    public static string Decrypt(string ciphervalue)
    {
        if (!s_keys_are_setup) return "No keys are setup";

        if (String.IsNullOrEmpty(ciphervalue)) return "No ciphertext";

        StringBuilder plaintext = new StringBuilder();
        try
        {
            C = new BigInteger(ciphervalue.ToString(), 10);

            // generate plainvalue from ciphervalue
            dM = C.modPow(X, N);
            string dMString = dM.ToString();
            // left-pad with 0 if needed
            if ((dMString.Length % CHAR_DIGITS) != 0)
            {
                dMString = "0" + dMString;
            }

            // build plaintext from plainvalue
            for (int i = 0; i < dMString.Length; i += CHAR_DIGITS)
            {
                try
                {
                    int j = int.Parse(dMString.Substring(i, CHAR_DIGITS));
                    plaintext.Append(String.Format("{0:02}", s_conversion_table[j - CHAR_SHIFT]));
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
        catch (Exception ex)
        {
            // not supported char in message
            throw ex;
        }
        return plaintext.ToString();
    }
}
