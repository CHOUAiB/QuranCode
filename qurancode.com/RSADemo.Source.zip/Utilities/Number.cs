﻿using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.IO;

public class Number
{
    private static bool s_one_is_prime = true;
    public static bool OneIsPrime
    {
        get { return s_one_is_prime; }
        set { s_one_is_prime = value; }
    }

    public static bool IsOdd(long number)
    {
        return ((number % 2) == 1);
    }
    public static bool IsEven(long number)
    {
        return ((number % 2) == 0);
    }
    public static bool IsPrime(long number)
    {
        if (number <= 0)        // primes are positive
            return false;

        if (number == 1)
            return s_one_is_prime;

        if (number == 2)        // 2 is the only even prime
            return true;

        if (number % 2 == 0)    // exclude even numbers
            return false;

        long sqrt = (long)Math.Sqrt(number);
        for (long i = 3; i <= sqrt; i += 2)
        {
            if ((number % i) == 0)
            {
                return false;
            }
        }
        return true;
    }
    public static long DigitSum(long number)
    {
        long digit_sum = 0;
        try
        {
            string str = number.ToString();
            for (int i = 0; i < str.Length; i++)
            {
                digit_sum += (long)char.GetNumericValue(str[i]);
            }
        }
        catch (Exception ex)
        {
            return 0;
        }
        return digit_sum;
    }
    public static bool IsPrimeDigitSum(long number)
    {
        return IsPrime(DigitSum(number));
    }
    public static bool IsPrimeDigits(long number)
    {
        try
        {
            string str = number.ToString();
            for (int i = 0; i < str.Length; i++)
            {
                if (!IsPrime((long)char.GetNumericValue(str[i])))
                {
                    return false;
                }
            }
        }
        catch (Exception ex)
        {
            return false;
        }
        return true;
    }
    public static bool IsAdditivePrime(long number)
    {
        if (IsPrime(number))
        {
            return IsPrimeDigitSum(number);
        }
        return false;
    }
    public static bool IsPurePrime(long number)
    {
        if (IsPrime(number))
        {
            if (IsPrimeDigits(number))
            {
                return IsPrimeDigitSum(number);
            }
            return false;
        }
        return false;
    }
    public static List<int> GetDigits(long number)
    {
        List<int> digits = new List<int>();
        try
        {
            string str = number.ToString();
            for (int i = 0; i < str.Length; i++)
            {
                digits.Add((int)Char.GetNumericValue(str[i]));
            }
        }
        catch (Exception ex)
        {
            return null;
        }
        return digits;
    }
    public static bool ArePrimeTriplets(long n1, long n2, long n3)
    {
        if (
            Number.IsAdditivePrime(n1)
            &&
            Number.IsAdditivePrime(n2)
            &&
            Number.IsAdditivePrime(n3)
            )
        {
            try
            {
                long l2r = long.Parse(n1.ToString() + n2.ToString() + n3.ToString());
                long r2l = long.Parse(n3.ToString() + n2.ToString() + n1.ToString());
                if (
                    Number.IsAdditivePrime(l2r)
                    &&
                    Number.IsAdditivePrime(r2l)
                    )
                {
                    return true;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        return false;
    }

    public static bool IsComposite(long number)
    {
        return !IsPrime(number);
    }
    public static bool IsCompositeDigits(long number)
    {
        try
        {
            string str = number.ToString();
            for (int i = 0; i < str.Length; i++)
            {
                if (IsPrime((long)char.GetNumericValue(str[i])))
                {
                    return false;
                }
            }
        }
        catch (Exception ex)
        {
            return false;
        }
        return true;
    }
    public static bool IsCompositeDigitSum(long number)
    {
        return !IsPrime(DigitSum(number));
    }
    public static bool IsAdditiveComposite(long number)
    {
        if (IsComposite(number))
        {
            return IsCompositeDigitSum(number);
        }
        return false;
    }
    public static bool IsPureComposite(long number)
    {
        if (IsComposite(number))
        {
            if (IsCompositeDigits(number))
            {
                return IsCompositeDigitSum(number);
            }
            return false;
        }
        return false;
    }

    public static long PrimeCount(long limit)
    {
        long count = 0;
        for (long i = 0; i <= limit; i++)
        {
            if (IsPrime(i))
            {
                count++;
            }
        }
        return count;
    }
    public static long AdditivePrimeCount(long limit)
    {
        int count = 0;
        for (long i = 0; i <= limit; i++)
        {
            if (IsAdditivePrime(i))
            {
                count++;
            }
        }
        return count;
    }
    public static long PurePrimeCount(long limit)
    {
        int count = 0;
        for (long i = 0; i <= limit; i++)
        {
            if (IsPurePrime(i))
            {
                count++;
            }
        }
        return count;
    }

    public static List<long> Factorize(long number)
    {
        List<long> prime_factors = new List<long>();
        if (number < 2)
        {
            // do nothing
        }
        else if (number == 2)
        {
            prime_factors.Add(number);
        }
        else // if (number > 2)
        {
            // if number has a prime factor add it to factors,
            // number /= p,
            // reloop until  number == 1
            while (number != 1)
            {
                if ((number % 2) == 0) // if even number
                {
                    prime_factors.Add(2);
                    number /= 2;
                }
                else // trial divide by all primes upto sqrt(number)
                {
                    long max = (long)(Math.Sqrt(number)) + 1;	// extra 1 for double calculation errors

                    bool is_factor_found = false;
                    for (long p = 3; p <= max; p += 2)		// should only use primes, but odds will do for now
                    {
                        if ((number % p) == 0)
                        {
                            is_factor_found = true;
                            prime_factors.Add(p);
                            number /= p;
                            break; // for loop, reloop while
                        }
                    }

                    // if no prime factor found the number must be prime in the first place
                    if (!is_factor_found)
                    {
                        prime_factors.Add(number);
                        break; // while loop
                    }
                }
            }
        }
        return prime_factors;
    }
    public static string FactorizeToString(long number)
    {
        string prime_factors_str = "";
        List<long> prime_factors = Factorize(number);
        foreach (long prime_factor in prime_factors)
        {
            prime_factors_str += prime_factor.ToString() + " x ";
        }
        if (prime_factors.Count > 0)
        {
            prime_factors_str = prime_factors_str.Remove(prime_factors_str.Length - 3, 3);
        }
        return prime_factors_str;
    }

    public static long Factorial(long number)
    {
        long result = 1;
        try
        {
            for (long i = 1; i <= number; i++)
            {
                result *= i;
            }
        }
        catch
        {
            result = -1;
        }
        return result;
    }

    // Initializer
    private static bool s_initialized = false;
    public static bool Initialize()
    {
        try
        {
            GenerateAllPrimeTypes(s_limit);
            GenerateAllCompositeTypes(s_limit);
            GenerateGematriaValues(100);
            GenerateLinearValues(100);
            s_initialized = true;
        }
        catch (Exception ex)
        {
            s_initialized = false;
        }
        return s_initialized;
    }


    /*
        Sieve of Eratosthenes in C# 
        February 26th, 2010  Comments(0) 
        In my personal quest to find out if the programming language really matters, I present to you my first piece of code.  This is my reference implementation of Sieve of Eratosthenes in my preferred language, C#.  For this and all future language implementations, I'll put the code at the top (without comments) and then narrate my experience below.  Now, to the code!

        IList<int> findPrimes(int max) {    var vals = new List<int>((int)(max/(Math.Log(max)-1.08366)));    var maxSquareRoot = Math.Sqrt(max);    var eliminated = new System.Collections.BitArray(max + 1);                            vals.Add(2);    for (int i = 3; i <= max; i+=2) {        if (!eliminated[i]) {            if (i < maxSquareRoot) {                for (int j = i * i; j <= max; j+=2*i)                    eliminated[j] = true;            }            vals.Add(i);        }    }    return vals;}I started by following the wikipedia definition and then optimized from there.

        Algorithm Optimizations
        I cut my work in half by treating the special case of '2'. We know that 2 is prime and all even numbers thereafter are not. So, we'll add two immediately and then start looping at 3 only checking odd numbers from there forward.

        After we've found a prime, we only need to eliminate numbers from it's square and forward. Let's say we want to find all prime numbers up to 100 and we've just identified 7 as a prime. Per the algorithm, I'll need to eliminate 2*7, 3*7 ,4*7, 5*7, 6*7, 7*7 ,8*7 ,9*7, 10*7 ,11*7, 12*7 ,13*7 and 14*7. None of the even multiples matter (even times an odd is always even) and none of the multiples up to the square of the prime matter since we've already done those multiples in previous loops. So really we only have to eliminate 7*7, 9*7, 11*7 and 13*7. That's a 9 fewer iterations and those savings become more fruitful the deeper you go!

        The last optimization is the square root calculation and check. We know from above that we only need to start eliminating beginning at the square of the current prime. Therefore it also makes sense that we can stop even trying once we get past the to square root of the max. This saves a bunch more iterations.

        Language Optimizations
        Originally I had started by returning an IEnumerable<int>. I wasn't using the list you see above and instead I was using yield return i. I really like that syntax, but once I got to the VB.net version (Coming Soon!), I didn't have a direct translation for the yield keyword. I took the lazy route in the VB version and just stuffed it all into a list and returned that. To my surprise it was faster! I went back and changed the C# version above and it performed better. I'm not sure why, but I'm going with it.

        What do you think that you get when do a sizeof(bool) in C#? I was surprised to find out that my trusty booleans actually take up a whole byte instead of a single bit. I speculate that there is a performance benefit that all of your types fit into a byte level offset in memory. I was thrilled to find out that we have a BitArray class that is useful for situations above when you need to store a lot of booleans and you need them to only take up a bit in memory. I'm not sure it helped anything, but I feel better knowing I'm using the least amount of memory possible. 

        Conclusion
        Despite the fact that I know C# really well, I'm very thrilled that I was able to learn a few things about the language. Also, I'm really happy with the performance of this reference implementation. On my machine (2.66 GHz Core2 Duo and 2 GB of RAM) I can find all of the primes under 1,000,000 in 19ms. I think I've squeezed all I can out of this version. Please let me know if you see something I missed or did wrong and I'll make adjustments.

        EDIT: I just added one more optimization that's worth noting. Instead of constructing my list with an empty constructor, I can save a several milliseconds off the larger sets by specifying a start size of the internal array structure behind the list. If I set this size at or slightly above the end count of prime numbers, then I avoid a lot of costly array copying as the array bounds keep getting hit. It turns out that there is quite a bit of math involved in accurately predicting the number of primes underneath a given number. I chose to cheat and just use Legendre's constant with the Prime Number Theorem which is close enough for my purposes. I can now calculate all primes under 1,000,000 in 10ms on my machine. Neat!
    */
    private static int s_limit = 10000; // 19314137 Simplified29, 28423968 Simplified37 PV, 86663282 Original
    public static int Limit
    {
        get { return s_limit; }
        set { s_limit = value; Initialize(); }
    }

    //--------------------------------
    //      Capacity	Used
    //--------------------------------
    //P     1290346		1289255
    //AP	645173		479693
    //PP	6971		6776
    private static List<long> s_primes = null;
    public static List<long> Primes
    {
        get
        {
            if (!s_initialized)
            {
                Initialize();
            }
            return s_primes;
        }
    }
    private static List<long> s_additive_primes = null;
    public static List<long> AdditivePrimes
    {
        get
        {
            if (!s_initialized)
            {
                Initialize();
            }
            return s_additive_primes;
        }
    }
    private static List<long> s_pure_primes = null;
    public static List<long> PurePrimes
    {
        get
        {
            if (!s_initialized)
            {
                Initialize();
            }
            return s_pure_primes;
        }
    }

    private static void GenerateAllPrimeTypes(int max)
    {
        s_primes = new List<long>((int)(max / (Math.Log(max) - 1.08366)));
        s_additive_primes = new List<long>((int)(max / ((Math.Log(max) - 1.08366) * 2.65)));
        s_pure_primes = new List<long>((int)(max / ((Math.Log(max) - 1.08366) * 190)));
        BitArray composites = new BitArray(max + 1);

        if (Number.OneIsPrime)
        {
            s_primes.Add(1);
            s_additive_primes.Add(1);
            s_pure_primes.Add(1);
        }
        s_primes.Add(2);
        s_additive_primes.Add(2);
        s_pure_primes.Add(2);
        long sqrt = (long)Math.Sqrt(max) + 1;
        for (int number = 3; number <= max; number += 2)
        {
            if (!composites[number])
            {
                if (number < sqrt)
                {
                    for (int j = number * number; j <= max; j += 2 * number)
                    {
                        composites[j] = true;
                    }
                }
                s_primes.Add(number);
                if (IsPrimeDigitSum(number))
                {
                    s_additive_primes.Add(number);
                    if (IsPrimeDigits(number))
                    {
                        s_pure_primes.Add(number);
                    }
                }
            }
        }
    }
    private static void GeneratePrimes(int max)
    {
        if (s_primes == null)
        {
            s_primes = new List<long>((int)(max / (Math.Log(max) - 1.08366)));
            BitArray sieve = new BitArray(max + 1);

            if (Number.OneIsPrime)
            {
                s_primes.Add(1);
            }
            s_primes.Add(2);
            long sqrt = (long)Math.Sqrt(max) + 1;
            for (int number = 3; number <= max; number += 2)
            {
                if (!sieve[number])
                {
                    // add prime
                    s_primes.Add(number);
                    // mark off its multiples
                    if (number < sqrt)
                    {
                        for (int j = number * number; j <= max; j += 2 * number)
                        {
                            sieve[j] = true;
                        }
                    }
                }
            }
        }
    }
    private static void GenerateAdditivePrimes(int max)
    {
        if (s_additive_primes == null)
        {
            s_additive_primes = new List<long>((int)(max / (Math.Log(max) - 1.08366)));
            BitArray sieve = new BitArray(max + 1);

            if (Number.OneIsPrime)
            {
                s_additive_primes.Add(1);
            }
            s_additive_primes.Add(2);
            long sqrt = (long)Math.Sqrt(max) + 1;
            for (int number = 3; number <= max; number += 2)
            {
                if (!sieve[number])
                {
                    // add prime
                    if (IsPrimeDigitSum(number))
                    {
                        s_additive_primes.Add(number);
                    }
                    // mark off its multiples
                    if (number < sqrt)
                    {
                        for (int j = number * number; j <= max; j += 2 * number)
                        {
                            sieve[j] = true;
                        }
                    }
                }
            }
        }
    }
    private static void GeneratePurePrimes(int max)
    {
        if (s_pure_primes == null)
        {
            s_pure_primes = new List<long>((int)(max / (Math.Log(max) - 1.08366)));
            BitArray sieve = new BitArray(max + 1);

            if (Number.OneIsPrime)
            {
                s_pure_primes.Add(1);
            }
            s_pure_primes.Add(2);
            long sqrt = (long)Math.Sqrt(max) + 1;
            for (int number = 3; number <= max; number += 2)
            {
                if (!sieve[number])
                {
                    // add prime
                    if (IsPrimeDigitSum(number))
                    {
                        if (IsPrimeDigits(number))
                        {
                            s_pure_primes.Add(number);
                        }
                    }
                    // mark off its multiples
                    if (number < sqrt)
                    {
                        for (int j = number * number; j <= max; j += 2 * number)
                        {
                            sieve[j] = true;
                        }
                    }
                }
            }
        }
    }
    public static int GetPrimeIndex(long number)
    {
        if (!s_initialized)
        {
            Initialize();
        }
        return BinaryFind(s_primes, number);
    }
    public static int GetAdditivePrimeIndex(long number)
    {
        if (!s_initialized)
        {
            Initialize();
        }
        return BinaryFind(s_additive_primes, number);
    }
    public static int GetPurePrimeIndex(long number)
    {
        if (!s_initialized)
        {
            Initialize();
        }
        return BinaryFind(s_pure_primes, number);
    }

    //--------------------------------
    //      Capacity	Used
    //--------------------------------
    //C	    20314137	19024881
    //AC	14510097	14502205
    //PC	58040		57768
    //--------------------------------
    private static List<long> s_composites = null;
    public static List<long> Composites
    {
        get
        {
            if (!s_initialized)
            {
                Initialize();
            }
            return s_composites;
        }
    }
    private static List<long> s_additive_composites = null;
    public static List<long> AdditiveComposites
    {
        get
        {
            if (!s_initialized)
            {
                Initialize();
            }
            return s_additive_composites;
        }
    }
    private static List<long> s_pure_composites = null;
    public static List<long> PureComposites
    {
        get
        {
            if (!s_initialized)
            {
                Initialize();
            }
            return s_pure_composites;
        }
    }
    private static void GenerateAllCompositeTypes(int max)
    {
        s_composites = new List<long>((int)(max));
        s_additive_composites = new List<long>((int)(max / 1.4));
        s_pure_composites = new List<long>((int)(max / 350));
        BitArray sieve = new BitArray(max + 1);

        for (int i = 4; i <= max; i += 2)
        {
            sieve[i] = true;
        }
        long sqrt = (long)Math.Sqrt(max) + 1;
        for (int number = 3; number <= max; number += 2)
        {
            if (!sieve[number])
            {
                // mark off its multiples
                if (number < sqrt)
                {
                    for (int j = number * number; j <= max; j += 2 * number)
                    {
                        sieve[j] = true;
                    }
                }
            }
        }

        for (int i = 2; i <= max; i++)
        {
            if (sieve[i])
            {
                s_composites.Add(i);
                if (!IsPrimeDigitSum(i))
                {
                    s_additive_composites.Add(i);
                    if (IsCompositeDigits(i))
                    {
                        s_pure_composites.Add(i);
                    }
                }
            }
        }
    }
    private static void GenerateComposites(int max)
    {
        s_composites = new List<long>((int)(max));
        BitArray sieve = new BitArray(max + 1);

        for (int i = 4; i <= max; i += 2)
        {
            sieve[i] = true;
        }
        long sqrt = (long)Math.Sqrt(max) + 1;
        for (int number = 3; number <= max; number += 2)
        {
            if (!sieve[number])
            {
                // mark off its multiples
                if (number < sqrt)
                {
                    for (int j = number * number; j <= max; j += 2 * number)
                    {
                        sieve[j] = true;
                    }
                }
            }
        }

        for (int i = 2; i <= max; i++)
        {
            if (sieve[i])
            {
                s_composites.Add(i);
            }
        }
    }
    private static void GenerateAdditiveComposites(int max)
    {
        s_additive_composites = new List<long>((int)(max / 1.4));
        BitArray sieve = new BitArray(max + 1);

        for (int i = 4; i <= max; i += 2)
        {
            sieve[i] = true;
        }
        long sqrt = (long)Math.Sqrt(max) + 1;
        for (int number = 3; number <= max; number += 2)
        {
            if (!sieve[number])
            {
                // mark off its multiples
                if (number < sqrt)
                {
                    for (int j = number * number; j <= max; j += 2 * number)
                    {
                        sieve[j] = true;
                    }
                }
            }
        }

        for (int i = 2; i <= max; i++)
        {
            if (sieve[i])
            {
                if (!IsPrimeDigitSum(i))
                {
                    s_additive_composites.Add(i);
                }
            }
        }
    }
    private static void GeneratePureComposites(int max)
    {
        s_pure_composites = new List<long>((int)(max / 350));
        BitArray sieve = new BitArray(max + 1);

        for (int i = 4; i <= max; i += 2)
        {
            sieve[i] = true;
        }
        long sqrt = (long)Math.Sqrt(max) + 1;
        for (int number = 3; number <= max; number += 2)
        {
            if (!sieve[number])
            {
                // mark off its multiples
                if (number < sqrt)
                {
                    for (int j = number * number; j <= max; j += 2 * number)
                    {
                        sieve[j] = true;
                    }
                }
            }
        }

        for (int i = 2; i <= max; i++)
        {
            if (sieve[i])
            {
                if (!IsPrimeDigitSum(i))
                {
                    if (IsCompositeDigits(i))
                    {
                        s_pure_composites.Add(i);
                    }
                }
            }
        }
    }
    public static int GetCompositeIndex(long number)
    {
        if (!s_initialized)
        {
            Initialize();
        }
        return BinaryFind(s_composites, number);
    }
    public static int GetAdditiveCompositeIndex(long number)
    {
        if (!s_initialized)
        {
            Initialize();
        }
        return BinaryFind(s_additive_composites, number);
    }
    public static int GetPureCompositeIndex(long number)
    {
        if (!s_initialized)
        {
            Initialize();
        }
        return BinaryFind(s_pure_composites, number);
    }

    public static List<long> GematriaValues = null;
    public static void GenerateGematriaValues(int count)
    {
        GematriaValues = new List<long>(count);

        long power = 0;
        long multiplier = (long)Math.Pow(10, power++); ;
        for (int i = 0; i < count; i++)
        {
            if (((i + 1) % 10) == 0)
            {
                count++;
                continue;
            }

            if ((i / 10) > Math.Log10(multiplier))
            {
                multiplier = (long)Math.Pow(10, power++);
            }

            long value = ((i + 1) % 10) * multiplier;

            GematriaValues.Add(value);
        }
    }

    public static List<long> LinearValues = null;
    public static void GenerateLinearValues(int count)
    {
        LinearValues = new List<long>(count);
        for (int i = 1; i <= count; i++)
        {
            LinearValues.Add(i);
        }
    }

    public static int BinaryFind(IList<long> sorted_list, long number)
    {
        if (sorted_list.Count < 1) return -1;

        int min = 0;
        int max = sorted_list.Count - 1;
        int old_mid = -1;
        int mid;
        while ((mid = (min + max) / 2) != old_mid)
        {
            if (number == sorted_list[min]) { return min; }

            if (number == sorted_list[max]) { return max; }

            if (number == sorted_list[mid]) { return mid; }
            else if (number < sorted_list[mid]) { max = mid; }
            else /*if (number > sorted_list[mid])*/ { min = mid; }

            old_mid = mid;
        }

        return -1;
    }
    public static void QuickSort(IList<long> list, int min, int max)
    {
        if (list.Count < 1) return;
        if (min > max) return;
        if ((min < 0) || (max >= list.Count)) return;

        int lo = min;
        int hi = max;
        long mid = list[(lo + hi) / 2];	// uses copy constructor

        do
        {
            while (list[lo] < mid)		// uses comparison operator
                lo++;
            while (mid < list[hi])
                hi--;

            if (lo <= hi)
            {
                long temp = list[hi];
                list[hi] = list[lo];
                list[hi] = temp;
                lo++;
                hi--;
            }
        }
        while (lo <= hi);

        if (hi > min)
            QuickSort(list, min, hi);
        if (lo < max)
            QuickSort(list, lo, max);
    }

    private static string s_prime_marker = "+";
    private static string s_additive_prime_marker = "++";
    private static string s_pure_prime_marker = "+++";
    public static string AnnotatePrime(long number)
    {
        return ((Number.IsPrime(number) ? ((Number.IsPurePrime(number) ? s_pure_prime_marker : Number.IsAdditivePrime(number) ? s_additive_prime_marker : s_prime_marker)) : "") + number);
        //return (number + "\t" + (Numbers.IsPrime(number) ? ((Numbers.IsPurePrime(number) ? pure_prime_marker : Numbers.IsAdditivePrime(number) ? additive_prime_marker : prime_marker)) : ""));
    }
    public static string GetLegend()
    {
        string result = String.Empty;
        result += "\r\n" + "----------------------------------------------------------------------------------";
        result += "\r\n" + "{0,3} => Prime number   = Number divisible by itself and 1 only " + s_prime_marker;
        result += "\r\n" + "{0,3} => Additive Prime = Prime number with a prime digit sum " + s_additive_prime_marker;
        result += "\r\n" + "{0,3} => Pure Prime     = Prime number with prime digits and a prime digit sum " + s_pure_prime_marker;
        result += "\r\n" + "----------------------------------------------------------------------------------";
        return result;
    }
    // This is not mine and NOT TESTED YET
    public string ConvertToArabicNumerals(string input)
    {
        System.Text.UTF8Encoding utf8Encoder = new UTF8Encoding();
        System.Text.Decoder utf8Decoder = utf8Encoder.GetDecoder();
        System.Text.StringBuilder convertedChars = new System.Text.StringBuilder();
        char[] convertedChar = new char[1];
        byte[] bytes = new byte[] { 217, 160 };
        char[] inputCharArray = input.ToCharArray();
        foreach (char c in inputCharArray)
        {
            if (char.IsDigit(c))
            {
                bytes[1] = Convert.ToByte(160 + char.GetNumericValue(c));
                utf8Decoder.GetChars(bytes, 0, 2, convertedChar, 0);
                convertedChars.Append(convertedChar[0]);
            }
            else
            {
                convertedChars.Append(c);
            }
        }
        return convertedChars.ToString();
    }
}
