﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

public delegate void UpdateProgress(int progress);
public delegate void UpdateResult(List<object> result);

public interface INotifiable
{
    void UpdateProgressMethod(int progress);
    void UpdateResultMethod(List<object> result);
}
