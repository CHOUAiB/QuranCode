using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Threading;

public class Processor
{
    private NotifiableForm p_notifiable_form = null;
    private UpdateProgress p_update_progress_delegate = null;
    private UpdateResult p_update_result_delegate = null;

    private DateTime m_start;
    private TimeSpan m_duration;
    private bool m_cancel;
    private int m_sleep_time;
    private long m_batch_size;
    private List<object> m_result;

    private static string s_MessageString;
    private static string s_pString;
    private static string s_qString;
    private static string s_nString;
    private static string s_rString;
    private static string s_eString;
    private static string s_xString;
    private static string s_yString;
    private static string s_mString;
    private static string s_cString;
    private static string s_dMString;
    private static string s_dMessageString;

    private bool SetupKeys(string pString, string qString)
    {
        if (String.IsNullOrEmpty(pString)) return false;
        if (String.IsNullOrEmpty(qString)) return false;

        // setup if not setup yet or p or q has changed
        if
            (
                !RSA.KeysAreSetup ||
                (RSA.P.ToString() != pString) ||
                (RSA.Q.ToString() != qString)
            )
        {
            try
            {
                Cursor.Current = Cursors.WaitCursor;

                RSA.SetupKeys(pString, qString);

                s_pString = RSA.P.ToString();
                s_qString = RSA.Q.ToString();
                s_nString = RSA.N.ToString();
                s_rString = RSA.R.ToString();
                s_eString = RSA.E.ToString();
                s_xString = RSA.X.ToString();
                s_yString = RSA.Y.ToString();
            }
            catch (Exception ex)
            {
                throw ex;
                //MessageBox.Show(ex.Message, "Error");
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }

        return true;
    }
    private string EncryptMessage(string message)
    {
        if (String.IsNullOrEmpty(message)) return "0";

        s_MessageString = message;

        try
        {
            Cursor.Current = Cursors.WaitCursor;

            if (RSA.KeysAreSetup)
            {
                s_dMString = RSA.Encrypt(s_MessageString);

                s_mString = RSA.M.ToString();
                s_cString = RSA.C.ToString();

                // left-pad with zero if needed
                if ((s_mString.Length % RSA.CHAR_DIGITS) != 0)
                {
                    s_mString = "0" + s_mString;
                }
                if ((s_cString.Length % RSA.CHAR_DIGITS) != 0)
                {
                    s_cString = "0" + s_cString;
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
            //MessageBox.Show(ex.Message, "Error");
        }
        finally
        {
            Cursor.Current = Cursors.Default;
        }

        return s_cString;
    }
    private string DecryptMessage(string ciphervalue)
    {
        if (String.IsNullOrEmpty(ciphervalue)) return "0";

        s_cString = ciphervalue;

        try
        {
            Cursor.Current = Cursors.WaitCursor;

            if (RSA.KeysAreSetup)
            {
                s_dMessageString = RSA.Decrypt(s_cString);

                s_dMString = RSA.dM.ToString();

                // left-pad with zero if needed
                if ((s_dMString.Length % RSA.CHAR_DIGITS) != 0)
                {
                    s_dMString = "0" + s_dMString;
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
            //MessageBox.Show(ex.Message, "Error");
        }
        finally
        {
            Cursor.Current = Cursors.Default;
        }

        return s_dMessageString;
    }

    public Processor(NotifiableForm notifiable_form, string message, string pString, string qString)
    {
        this.p_notifiable_form = notifiable_form;
        if (p_notifiable_form != null)
        {
            // hook update delegates to the methods to be invoked
            p_update_progress_delegate = p_notifiable_form.UpdateProgressMethod;
            p_update_result_delegate = p_notifiable_form.UpdateResultMethod;
        }
        m_start = DateTime.Now;
        m_duration = TimeSpan.Zero;
        m_cancel = false;
        m_sleep_time = 100;
        m_batch_size = 10000L;
        m_result = new List<object>();

        s_MessageString = message;
        SetupKeys(pString, qString);
    }

    public TimeSpan Duration
    {
        get { return m_duration; }
    }

    public List<object> Result
    {
        get { return m_result; }
    }

    public bool Cancel
    {
        get { return m_cancel; }
        set { m_cancel = value; }
    }

    public void Run()
    {
        if (p_notifiable_form != null)
        {
            ///////////////////////////////////////////////////////////////////////////////////////////////////
            m_start = DateTime.Now;
            ///////////////////////////////////////////////////////////////////////////////////////////////////

            m_cancel = false;

            try
            {
                long max = 1; //1000000;
                for (long i = 0; i < max; i++)
                {
                    // stop on cancel request
                    if (m_cancel)
                    {
                        break;
                    }

                    ///////////////////////////////////////////////////////////////////////////
                    // run task here
                    ///////////////////////////////////////////////////////////////////////////
                    m_result.Clear();

                    s_cString = EncryptMessage(s_MessageString);
                    if (!String.IsNullOrEmpty(s_cString))
                    {
                        s_dMessageString = DecryptMessage(s_cString);
                    }

                    // fill result to return to calling thread
                    m_result.Add(s_MessageString);
                    m_result.Add(s_nString);
                    m_result.Add(s_rString);
                    m_result.Add(s_eString);
                    m_result.Add(s_xString);
                    m_result.Add(s_yString);
                    m_result.Add(s_mString);
                    m_result.Add(s_cString);
                    m_result.Add(s_dMString);
                    m_result.Add(s_dMessageString);
                    ///////////////////////////////////////////////////////////////////////////

                    // update every batch_size iterations
                    if ((i % m_batch_size) == 0L)
                    {
                        m_duration = DateTime.Now - m_start;
                        p_notifiable_form.BeginInvoke(p_update_result_delegate, new object[] { m_result });
                        p_notifiable_form.BeginInvoke(p_update_progress_delegate, new object[] { ((int)((long)(i * 100L) / max)) });
                        Thread.Sleep(m_sleep_time);
                    }
                }

                // finished normally, send 100% progress
                if (!m_cancel)
                {
                    m_duration = DateTime.Now - m_start;
                    p_notifiable_form.BeginInvoke(p_update_result_delegate, new object[] { m_result });
                    p_notifiable_form.BeginInvoke(p_update_progress_delegate, new object[] { (int)(100) });
                    Thread.Sleep(m_sleep_time);
                }
            }
            catch (Exception ex)
            {
                // cancel programmatically
                m_cancel = true;

                // send -1  --> process was cancelled
                m_duration = DateTime.Now - m_start;
                p_notifiable_form.BeginInvoke(p_update_progress_delegate, new object[] { -1 });
                Thread.Sleep(m_sleep_time);
            }
        }
    }
}
