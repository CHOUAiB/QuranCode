﻿partial class NotifiableForm
{
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        this.components = new System.ComponentModel.Container();
        System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NotifiableForm));
        this.ElapsedTimeLabel = new System.Windows.Forms.Label();
        this.ProgressLabel = new System.Windows.Forms.Label();
        this.ElapsedTimeValueLabel = new System.Windows.Forms.Label();
        this.ProgressValueLabel = new System.Windows.Forms.Label();
        this.MainMenu = new System.Windows.Forms.MainMenu(this.components);
        this.ProgressBar = new System.Windows.Forms.ProgressBar();
        this.RunButton = new System.Windows.Forms.Button();
        this.CloseButton = new System.Windows.Forms.Button();
        this.ProcessorGroupBox = new System.Windows.Forms.GroupBox();
        this.MilliSecondsLabel = new System.Windows.Forms.Label();
        this.SetupGroupBox = new System.Windows.Forms.GroupBox();
        this.Step4Label = new System.Windows.Forms.Label();
        this.Step1Label = new System.Windows.Forms.Label();
        this.pLabel = new System.Windows.Forms.Label();
        this.eLabel = new System.Windows.Forms.Label();
        this.yTextBox = new System.Windows.Forms.TextBox();
        this.eTextBox = new System.Windows.Forms.TextBox();
        this.pTextBox = new System.Windows.Forms.TextBox();
        this.rTextBox = new System.Windows.Forms.TextBox();
        this.yLabel = new System.Windows.Forms.Label();
        this.rLabel = new System.Windows.Forms.Label();
        this.qLabel = new System.Windows.Forms.Label();
        this.Step2Label = new System.Windows.Forms.Label();
        this.Step3Label = new System.Windows.Forms.Label();
        this.nTextBox = new System.Windows.Forms.TextBox();
        this.qTextBox = new System.Windows.Forms.TextBox();
        this.xLabel = new System.Windows.Forms.Label();
        this.xTextBox = new System.Windows.Forms.TextBox();
        this.nLabel = new System.Windows.Forms.Label();
        this.rHintLabel = new System.Windows.Forms.Label();
        this.EncryptionGroupBox = new System.Windows.Forms.GroupBox();
        this.mLabel = new System.Windows.Forms.Label();
        this.mTextBox = new System.Windows.Forms.TextBox();
        this.Step6Label = new System.Windows.Forms.Label();
        this.Step5Label = new System.Windows.Forms.Label();
        this.MessageLabel = new System.Windows.Forms.Label();
        this.MessageTextBox = new System.Windows.Forms.TextBox();
        this.cLabel = new System.Windows.Forms.Label();
        this.cTextBox = new System.Windows.Forms.TextBox();
        this.DecryptionGroupBox = new System.Windows.Forms.GroupBox();
        this.cReceivedLabel = new System.Windows.Forms.Label();
        this.cReceivedTextBox = new System.Windows.Forms.TextBox();
        this.dMessageLabel = new System.Windows.Forms.Label();
        this.dMessageTextBox = new System.Windows.Forms.TextBox();
        this.Step7Label = new System.Windows.Forms.Label();
        this.dMLabel = new System.Windows.Forms.Label();
        this.dMTextBox = new System.Windows.Forms.TextBox();
        this.ProcessorGroupBox.SuspendLayout();
        this.SetupGroupBox.SuspendLayout();
        this.EncryptionGroupBox.SuspendLayout();
        this.DecryptionGroupBox.SuspendLayout();
        this.SuspendLayout();
        // 
        // ElapsedTimeLabel
        // 
        this.ElapsedTimeLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.ElapsedTimeLabel.BackColor = System.Drawing.SystemColors.Info;
        this.ElapsedTimeLabel.Cursor = System.Windows.Forms.Cursors.Arrow;
        this.ElapsedTimeLabel.Font = new System.Drawing.Font("Tahoma", 8F);
        this.ElapsedTimeLabel.ForeColor = System.Drawing.SystemColors.ControlDark;
        this.ElapsedTimeLabel.Location = new System.Drawing.Point(111, 8);
        this.ElapsedTimeLabel.Name = "ElapsedTimeLabel";
        this.ElapsedTimeLabel.Size = new System.Drawing.Size(149, 16);
        this.ElapsedTimeLabel.TabIndex = 36;
        this.ElapsedTimeLabel.Text = "Elapsed Time";
        this.ElapsedTimeLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
        // 
        // ProgressLabel
        // 
        this.ProgressLabel.BackColor = System.Drawing.SystemColors.Info;
        this.ProgressLabel.Font = new System.Drawing.Font("Tahoma", 8F);
        this.ProgressLabel.ForeColor = System.Drawing.SystemColors.ControlDark;
        this.ProgressLabel.Location = new System.Drawing.Point(0, 8);
        this.ProgressLabel.Name = "ProgressLabel";
        this.ProgressLabel.Size = new System.Drawing.Size(131, 16);
        this.ProgressLabel.TabIndex = 35;
        this.ProgressLabel.Text = "Progress";
        this.ProgressLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
        // 
        // ElapsedTimeValueLabel
        // 
        this.ElapsedTimeValueLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.ElapsedTimeValueLabel.BackColor = System.Drawing.SystemColors.ControlDark;
        this.ElapsedTimeValueLabel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
        this.ElapsedTimeValueLabel.ForeColor = System.Drawing.SystemColors.Control;
        this.ElapsedTimeValueLabel.Location = new System.Drawing.Point(95, 22);
        this.ElapsedTimeValueLabel.Name = "ElapsedTimeValueLabel";
        this.ElapsedTimeValueLabel.Size = new System.Drawing.Size(165, 17);
        this.ElapsedTimeValueLabel.TabIndex = 34;
        this.ElapsedTimeValueLabel.Text = "00:00:00";
        this.ElapsedTimeValueLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
        // 
        // ProgressValueLabel
        // 
        this.ProgressValueLabel.BackColor = System.Drawing.SystemColors.ControlDark;
        this.ProgressValueLabel.Font = new System.Drawing.Font("Tahoma", 10F, System.Drawing.FontStyle.Bold);
        this.ProgressValueLabel.ForeColor = System.Drawing.SystemColors.Control;
        this.ProgressValueLabel.Location = new System.Drawing.Point(0, 22);
        this.ProgressValueLabel.Name = "ProgressValueLabel";
        this.ProgressValueLabel.Size = new System.Drawing.Size(131, 17);
        this.ProgressValueLabel.TabIndex = 30;
        this.ProgressValueLabel.Text = "0%";
        this.ProgressValueLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
        // 
        // ProgressBar
        // 
        this.ProgressBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.ProgressBar.Cursor = System.Windows.Forms.Cursors.Hand;
        this.ProgressBar.Location = new System.Drawing.Point(0, 39);
        this.ProgressBar.Name = "ProgressBar";
        this.ProgressBar.Size = new System.Drawing.Size(260, 10);
        this.ProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
        this.ProgressBar.TabIndex = 25;
        this.ProgressBar.Click += new System.EventHandler(this.ProgressBar_Click);
        // 
        // RunButton
        // 
        this.RunButton.Location = new System.Drawing.Point(1, 48);
        this.RunButton.Name = "RunButton";
        this.RunButton.Size = new System.Drawing.Size(130, 23);
        this.RunButton.TabIndex = 13;
        this.RunButton.Text = "Run";
        this.RunButton.UseVisualStyleBackColor = true;
        this.RunButton.Click += new System.EventHandler(this.RunButton_Click);
        // 
        // CloseButton
        // 
        this.CloseButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                    | System.Windows.Forms.AnchorStyles.Right)));
        this.CloseButton.Location = new System.Drawing.Point(130, 48);
        this.CloseButton.Name = "CloseButton";
        this.CloseButton.Size = new System.Drawing.Size(130, 23);
        this.CloseButton.TabIndex = 14;
        this.CloseButton.Text = "Close";
        this.CloseButton.UseVisualStyleBackColor = true;
        this.CloseButton.Click += new System.EventHandler(this.CloseButton_Click);
        // 
        // ProcessorGroupBox
        // 
        this.ProcessorGroupBox.Controls.Add(this.RunButton);
        this.ProcessorGroupBox.Controls.Add(this.CloseButton);
        this.ProcessorGroupBox.Controls.Add(this.ProgressBar);
        this.ProcessorGroupBox.Controls.Add(this.ElapsedTimeLabel);
        this.ProcessorGroupBox.Controls.Add(this.MilliSecondsLabel);
        this.ProcessorGroupBox.Controls.Add(this.ProgressLabel);
        this.ProcessorGroupBox.Controls.Add(this.ElapsedTimeValueLabel);
        this.ProcessorGroupBox.Controls.Add(this.ProgressValueLabel);
        this.ProcessorGroupBox.Dock = System.Windows.Forms.DockStyle.Bottom;
        this.ProcessorGroupBox.Location = new System.Drawing.Point(0, 508);
        this.ProcessorGroupBox.Name = "ProcessorGroupBox";
        this.ProcessorGroupBox.Size = new System.Drawing.Size(260, 72);
        this.ProcessorGroupBox.TabIndex = 42;
        this.ProcessorGroupBox.TabStop = false;
        // 
        // MilliSecondsLabel
        // 
        this.MilliSecondsLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.MilliSecondsLabel.BackColor = System.Drawing.SystemColors.ControlDark;
        this.MilliSecondsLabel.Font = new System.Drawing.Font("Tahoma", 8F);
        this.MilliSecondsLabel.ForeColor = System.Drawing.SystemColors.Control;
        this.MilliSecondsLabel.Location = new System.Drawing.Point(211, 25);
        this.MilliSecondsLabel.Name = "MilliSecondsLabel";
        this.MilliSecondsLabel.Size = new System.Drawing.Size(25, 12);
        this.MilliSecondsLabel.TabIndex = 33;
        this.MilliSecondsLabel.Text = "000";
        // 
        // SetupGroupBox
        // 
        this.SetupGroupBox.BackColor = System.Drawing.Color.LightSkyBlue;
        this.SetupGroupBox.Controls.Add(this.Step4Label);
        this.SetupGroupBox.Controls.Add(this.Step1Label);
        this.SetupGroupBox.Controls.Add(this.pLabel);
        this.SetupGroupBox.Controls.Add(this.eLabel);
        this.SetupGroupBox.Controls.Add(this.yTextBox);
        this.SetupGroupBox.Controls.Add(this.eTextBox);
        this.SetupGroupBox.Controls.Add(this.pTextBox);
        this.SetupGroupBox.Controls.Add(this.rTextBox);
        this.SetupGroupBox.Controls.Add(this.yLabel);
        this.SetupGroupBox.Controls.Add(this.rLabel);
        this.SetupGroupBox.Controls.Add(this.qLabel);
        this.SetupGroupBox.Controls.Add(this.Step2Label);
        this.SetupGroupBox.Controls.Add(this.Step3Label);
        this.SetupGroupBox.Controls.Add(this.nTextBox);
        this.SetupGroupBox.Controls.Add(this.qTextBox);
        this.SetupGroupBox.Controls.Add(this.xLabel);
        this.SetupGroupBox.Controls.Add(this.xTextBox);
        this.SetupGroupBox.Controls.Add(this.nLabel);
        this.SetupGroupBox.Controls.Add(this.rHintLabel);
        this.SetupGroupBox.Dock = System.Windows.Forms.DockStyle.Top;
        this.SetupGroupBox.ForeColor = System.Drawing.SystemColors.WindowText;
        this.SetupGroupBox.Location = new System.Drawing.Point(0, 0);
        this.SetupGroupBox.Name = "SetupGroupBox";
        this.SetupGroupBox.Size = new System.Drawing.Size(260, 272);
        this.SetupGroupBox.TabIndex = 43;
        this.SetupGroupBox.TabStop = false;
        this.SetupGroupBox.Text = "Setup Keys";
        // 
        // Step4Label
        // 
        this.Step4Label.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.Step4Label.Location = new System.Drawing.Point(5, 247);
        this.Step4Label.Name = "Step4Label";
        this.Step4Label.Size = new System.Drawing.Size(245, 17);
        this.Step4Label.TabIndex = 20;
        this.Step4Label.Text = "4. Publish e and n as public key";
        // 
        // Step1Label
        // 
        this.Step1Label.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.Step1Label.Location = new System.Drawing.Point(6, 18);
        this.Step1Label.Name = "Step1Label";
        this.Step1Label.Size = new System.Drawing.Size(246, 17);
        this.Step1Label.TabIndex = 11;
        this.Step1Label.Text = "1. Choose two prime numbers p and q";
        // 
        // pLabel
        // 
        this.pLabel.Location = new System.Drawing.Point(16, 39);
        this.pLabel.Name = "pLabel";
        this.pLabel.Size = new System.Drawing.Size(139, 17);
        this.pLabel.TabIndex = 2;
        this.pLabel.Text = "p   [any prime number]";
        // 
        // eLabel
        // 
        this.eLabel.Location = new System.Drawing.Point(15, 159);
        this.eLabel.Name = "eLabel";
        this.eLabel.Size = new System.Drawing.Size(140, 17);
        this.eLabel.TabIndex = 10;
        this.eLabel.Text = "e   [public, coprime to r]";
        // 
        // yTextBox
        // 
        this.yTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.yTextBox.BackColor = System.Drawing.SystemColors.Control;
        this.yTextBox.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.yTextBox.Location = new System.Drawing.Point(161, 223);
        this.yTextBox.Name = "yTextBox";
        this.yTextBox.Size = new System.Drawing.Size(90, 20);
        this.yTextBox.TabIndex = 7;
        this.yTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        // 
        // eTextBox
        // 
        this.eTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.eTextBox.BackColor = System.Drawing.SystemColors.Control;
        this.eTextBox.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.eTextBox.Location = new System.Drawing.Point(161, 157);
        this.eTextBox.Name = "eTextBox";
        this.eTextBox.Size = new System.Drawing.Size(90, 20);
        this.eTextBox.TabIndex = 5;
        this.eTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        // 
        // pTextBox
        // 
        this.pTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.pTextBox.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.pTextBox.Location = new System.Drawing.Point(161, 37);
        this.pTextBox.Name = "pTextBox";
        this.pTextBox.Size = new System.Drawing.Size(90, 20);
        this.pTextBox.TabIndex = 1;
        this.pTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        this.pTextBox.TextChanged += new System.EventHandler(this.TextBox_TextChanged);
        // 
        // rTextBox
        // 
        this.rTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.rTextBox.BackColor = System.Drawing.SystemColors.Control;
        this.rTextBox.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.rTextBox.Location = new System.Drawing.Point(161, 100);
        this.rTextBox.Name = "rTextBox";
        this.rTextBox.Size = new System.Drawing.Size(90, 20);
        this.rTextBox.TabIndex = 4;
        this.rTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        // 
        // yLabel
        // 
        this.yLabel.Location = new System.Drawing.Point(14, 224);
        this.yLabel.Name = "yLabel";
        this.yLabel.Size = new System.Drawing.Size(141, 17);
        this.yLabel.TabIndex = 17;
        this.yLabel.Text = "y   [satisfy e*x - r*y = 1]";
        // 
        // rLabel
        // 
        this.rLabel.Location = new System.Drawing.Point(15, 102);
        this.rLabel.Name = "rLabel";
        this.rLabel.Size = new System.Drawing.Size(140, 17);
        this.rLabel.TabIndex = 8;
        this.rLabel.Text = "r = (p-1) * (q-1)";
        // 
        // qLabel
        // 
        this.qLabel.Location = new System.Drawing.Point(15, 60);
        this.qLabel.Name = "qLabel";
        this.qLabel.Size = new System.Drawing.Size(139, 17);
        this.qLabel.TabIndex = 4;
        this.qLabel.Text = "q   [any prime number]";
        // 
        // Step2Label
        // 
        this.Step2Label.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.Step2Label.Location = new System.Drawing.Point(6, 139);
        this.Step2Label.Name = "Step2Label";
        this.Step2Label.Size = new System.Drawing.Size(246, 17);
        this.Step2Label.TabIndex = 12;
        this.Step2Label.Text = "2. Choose e such that e and r are coprimes";
        // 
        // Step3Label
        // 
        this.Step3Label.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.Step3Label.Location = new System.Drawing.Point(5, 182);
        this.Step3Label.Name = "Step3Label";
        this.Step3Label.Size = new System.Drawing.Size(246, 17);
        this.Step3Label.TabIndex = 15;
        this.Step3Label.Text = "3. Choose x and y such that   e*x - r*y = 1 ";
        // 
        // nTextBox
        // 
        this.nTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.nTextBox.BackColor = System.Drawing.SystemColors.Control;
        this.nTextBox.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.nTextBox.Location = new System.Drawing.Point(161, 79);
        this.nTextBox.Name = "nTextBox";
        this.nTextBox.Size = new System.Drawing.Size(90, 20);
        this.nTextBox.TabIndex = 3;
        this.nTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        // 
        // qTextBox
        // 
        this.qTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.qTextBox.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.qTextBox.Location = new System.Drawing.Point(161, 58);
        this.qTextBox.Name = "qTextBox";
        this.qTextBox.Size = new System.Drawing.Size(90, 20);
        this.qTextBox.TabIndex = 2;
        this.qTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        this.qTextBox.TextChanged += new System.EventHandler(this.TextBox_TextChanged);
        // 
        // xLabel
        // 
        this.xLabel.Location = new System.Drawing.Point(14, 203);
        this.xLabel.Name = "xLabel";
        this.xLabel.Size = new System.Drawing.Size(141, 17);
        this.xLabel.TabIndex = 14;
        this.xLabel.Text = "x   [private, del p, q, r, y]";
        // 
        // xTextBox
        // 
        this.xTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.xTextBox.BackColor = System.Drawing.SystemColors.Control;
        this.xTextBox.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.xTextBox.Location = new System.Drawing.Point(161, 202);
        this.xTextBox.Name = "xTextBox";
        this.xTextBox.Size = new System.Drawing.Size(90, 20);
        this.xTextBox.TabIndex = 6;
        this.xTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        // 
        // nLabel
        // 
        this.nLabel.Location = new System.Drawing.Point(15, 81);
        this.nLabel.Name = "nLabel";
        this.nLabel.Size = new System.Drawing.Size(140, 17);
        this.nLabel.TabIndex = 6;
        this.nLabel.Text = "n = p * q   [public divisor]";
        // 
        // rHintLabel
        // 
        this.rHintLabel.ForeColor = System.Drawing.Color.LavenderBlush;
        this.rHintLabel.Location = new System.Drawing.Point(15, 119);
        this.rHintLabel.Name = "rHintLabel";
        this.rHintLabel.Size = new System.Drawing.Size(236, 17);
        this.rHintLabel.TabIndex = 21;
        this.rHintLabel.Text = "r is the number of mod n remainers coprime to n";
        // 
        // EncryptionGroupBox
        // 
        this.EncryptionGroupBox.Controls.Add(this.mLabel);
        this.EncryptionGroupBox.Controls.Add(this.mTextBox);
        this.EncryptionGroupBox.Controls.Add(this.Step6Label);
        this.EncryptionGroupBox.Controls.Add(this.Step5Label);
        this.EncryptionGroupBox.Controls.Add(this.MessageLabel);
        this.EncryptionGroupBox.Controls.Add(this.MessageTextBox);
        this.EncryptionGroupBox.Controls.Add(this.cLabel);
        this.EncryptionGroupBox.Controls.Add(this.cTextBox);
        this.EncryptionGroupBox.Dock = System.Windows.Forms.DockStyle.Top;
        this.EncryptionGroupBox.ForeColor = System.Drawing.SystemColors.WindowText;
        this.EncryptionGroupBox.Location = new System.Drawing.Point(0, 272);
        this.EncryptionGroupBox.Name = "EncryptionGroupBox";
        this.EncryptionGroupBox.Size = new System.Drawing.Size(260, 136);
        this.EncryptionGroupBox.TabIndex = 44;
        this.EncryptionGroupBox.TabStop = false;
        this.EncryptionGroupBox.Text = "Encryption";
        // 
        // mLabel
        // 
        this.mLabel.Location = new System.Drawing.Point(16, 63);
        this.mLabel.Name = "mLabel";
        this.mLabel.Size = new System.Drawing.Size(139, 17);
        this.mLabel.TabIndex = 21;
        this.mLabel.Text = "M   [as ASCII values]";
        // 
        // mTextBox
        // 
        this.mTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.mTextBox.BackColor = System.Drawing.SystemColors.Control;
        this.mTextBox.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.mTextBox.Location = new System.Drawing.Point(161, 61);
        this.mTextBox.Name = "mTextBox";
        this.mTextBox.Size = new System.Drawing.Size(91, 20);
        this.mTextBox.TabIndex = 9;
        this.mTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        // 
        // Step6Label
        // 
        this.Step6Label.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.Step6Label.Location = new System.Drawing.Point(5, 112);
        this.Step6Label.Name = "Step6Label";
        this.Step6Label.Size = new System.Drawing.Size(246, 17);
        this.Step6Label.TabIndex = 20;
        this.Step6Label.Text = "6. Publish encrypted message C";
        // 
        // Step5Label
        // 
        this.Step5Label.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.Step5Label.Location = new System.Drawing.Point(6, 20);
        this.Step5Label.Name = "Step5Label";
        this.Step5Label.Size = new System.Drawing.Size(246, 17);
        this.Step5Label.TabIndex = 11;
        this.Step5Label.Text = "5. Encrypt message M";
        // 
        // MessageLabel
        // 
        this.MessageLabel.Location = new System.Drawing.Point(16, 41);
        this.MessageLabel.Name = "MessageLabel";
        this.MessageLabel.Size = new System.Drawing.Size(139, 17);
        this.MessageLabel.TabIndex = 2;
        this.MessageLabel.Text = "Message";
        // 
        // MessageTextBox
        // 
        this.MessageTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.MessageTextBox.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.MessageTextBox.Location = new System.Drawing.Point(161, 39);
        this.MessageTextBox.Name = "MessageTextBox";
        this.MessageTextBox.Size = new System.Drawing.Size(91, 20);
        this.MessageTextBox.TabIndex = 8;
        this.MessageTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        this.MessageTextBox.TextChanged += new System.EventHandler(this.TextBox_TextChanged);
        // 
        // cLabel
        // 
        this.cLabel.Location = new System.Drawing.Point(16, 85);
        this.cLabel.Name = "cLabel";
        this.cLabel.Size = new System.Drawing.Size(139, 17);
        this.cLabel.TabIndex = 4;
        this.cLabel.Text = "C  =  M ^ e  (mod n)";
        // 
        // cTextBox
        // 
        this.cTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.cTextBox.BackColor = System.Drawing.SystemColors.Control;
        this.cTextBox.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.cTextBox.Location = new System.Drawing.Point(161, 83);
        this.cTextBox.Name = "cTextBox";
        this.cTextBox.Size = new System.Drawing.Size(91, 20);
        this.cTextBox.TabIndex = 10;
        this.cTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        // 
        // DecryptionGroupBox
        // 
        this.DecryptionGroupBox.BackColor = System.Drawing.Color.Thistle;
        this.DecryptionGroupBox.Controls.Add(this.cReceivedLabel);
        this.DecryptionGroupBox.Controls.Add(this.cReceivedTextBox);
        this.DecryptionGroupBox.Controls.Add(this.dMessageLabel);
        this.DecryptionGroupBox.Controls.Add(this.dMessageTextBox);
        this.DecryptionGroupBox.Controls.Add(this.Step7Label);
        this.DecryptionGroupBox.Controls.Add(this.dMLabel);
        this.DecryptionGroupBox.Controls.Add(this.dMTextBox);
        this.DecryptionGroupBox.Dock = System.Windows.Forms.DockStyle.Top;
        this.DecryptionGroupBox.ForeColor = System.Drawing.SystemColors.WindowText;
        this.DecryptionGroupBox.Location = new System.Drawing.Point(0, 408);
        this.DecryptionGroupBox.Name = "DecryptionGroupBox";
        this.DecryptionGroupBox.Size = new System.Drawing.Size(260, 108);
        this.DecryptionGroupBox.TabIndex = 45;
        this.DecryptionGroupBox.TabStop = false;
        this.DecryptionGroupBox.Text = "Decryption";
        // 
        // cReceivedLabel
        // 
        this.cReceivedLabel.Location = new System.Drawing.Point(16, 41);
        this.cReceivedLabel.Name = "cReceivedLabel";
        this.cReceivedLabel.Size = new System.Drawing.Size(139, 17);
        this.cReceivedLabel.TabIndex = 13;
        this.cReceivedLabel.Text = "Received message C";
        // 
        // cReceivedTextBox
        // 
        this.cReceivedTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.cReceivedTextBox.BackColor = System.Drawing.SystemColors.Control;
        this.cReceivedTextBox.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.cReceivedTextBox.Location = new System.Drawing.Point(161, 39);
        this.cReceivedTextBox.Name = "cReceivedTextBox";
        this.cReceivedTextBox.Size = new System.Drawing.Size(91, 20);
        this.cReceivedTextBox.TabIndex = 14;
        this.cReceivedTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        // 
        // dMessageLabel
        // 
        this.dMessageLabel.Location = new System.Drawing.Point(16, 83);
        this.dMessageLabel.Name = "dMessageLabel";
        this.dMessageLabel.Size = new System.Drawing.Size(139, 17);
        this.dMessageLabel.TabIndex = 12;
        this.dMessageLabel.Text = "dM in ASCII chars";
        // 
        // dMessageTextBox
        // 
        this.dMessageTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.dMessageTextBox.BackColor = System.Drawing.SystemColors.Control;
        this.dMessageTextBox.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.dMessageTextBox.Location = new System.Drawing.Point(161, 81);
        this.dMessageTextBox.Name = "dMessageTextBox";
        this.dMessageTextBox.Size = new System.Drawing.Size(91, 20);
        this.dMessageTextBox.TabIndex = 12;
        this.dMessageTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        // 
        // Step7Label
        // 
        this.Step7Label.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.Step7Label.Location = new System.Drawing.Point(6, 20);
        this.Step7Label.Name = "Step7Label";
        this.Step7Label.Size = new System.Drawing.Size(246, 17);
        this.Step7Label.TabIndex = 11;
        this.Step7Label.Text = "7. Decrypt message C";
        // 
        // dMLabel
        // 
        this.dMLabel.Location = new System.Drawing.Point(16, 62);
        this.dMLabel.Name = "dMLabel";
        this.dMLabel.Size = new System.Drawing.Size(139, 17);
        this.dMLabel.TabIndex = 2;
        this.dMLabel.Text = "dM  =  C ^ x  (mod n)";
        // 
        // dMTextBox
        // 
        this.dMTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
        this.dMTextBox.BackColor = System.Drawing.SystemColors.Control;
        this.dMTextBox.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Bold);
        this.dMTextBox.Location = new System.Drawing.Point(161, 60);
        this.dMTextBox.Name = "dMTextBox";
        this.dMTextBox.Size = new System.Drawing.Size(91, 20);
        this.dMTextBox.TabIndex = 11;
        this.dMTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
        // 
        // NotifiableForm
        // 
        this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.BackColor = System.Drawing.Color.LightSteelBlue;
        this.ClientSize = new System.Drawing.Size(260, 580);
        this.Controls.Add(this.DecryptionGroupBox);
        this.Controls.Add(this.EncryptionGroupBox);
        this.Controls.Add(this.SetupGroupBox);
        this.Controls.Add(this.ProcessorGroupBox);
        this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
        this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
        this.KeyPreview = true;
        this.MaximizeBox = false;
        this.Menu = this.MainMenu;
        this.Name = "NotifiableForm";
        this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        this.Text = "RSA Demo by Ali Adams";
        this.Load += new System.EventHandler(this.MainForm_Load);
        this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
        this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
        this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
        this.ProcessorGroupBox.ResumeLayout(false);
        this.SetupGroupBox.ResumeLayout(false);
        this.SetupGroupBox.PerformLayout();
        this.EncryptionGroupBox.ResumeLayout(false);
        this.EncryptionGroupBox.PerformLayout();
        this.DecryptionGroupBox.ResumeLayout(false);
        this.DecryptionGroupBox.PerformLayout();
        this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Label ElapsedTimeLabel;
    private System.Windows.Forms.Label ProgressLabel;
    private System.Windows.Forms.Label ElapsedTimeValueLabel;
    private System.Windows.Forms.Label ProgressValueLabel;
    private System.Windows.Forms.MainMenu MainMenu;
    private System.Windows.Forms.ProgressBar ProgressBar;
    private System.Windows.Forms.Button RunButton;
    private System.Windows.Forms.Button CloseButton;
    private System.Windows.Forms.GroupBox ProcessorGroupBox;
    private System.Windows.Forms.Label MilliSecondsLabel;
    private System.Windows.Forms.GroupBox SetupGroupBox;
    private System.Windows.Forms.Label Step4Label;
    private System.Windows.Forms.Label Step1Label;
    private System.Windows.Forms.Label pLabel;
    private System.Windows.Forms.Label eLabel;
    private System.Windows.Forms.TextBox yTextBox;
    private System.Windows.Forms.TextBox eTextBox;
    private System.Windows.Forms.TextBox pTextBox;
    private System.Windows.Forms.TextBox rTextBox;
    private System.Windows.Forms.Label yLabel;
    private System.Windows.Forms.Label rLabel;
    private System.Windows.Forms.Label qLabel;
    private System.Windows.Forms.Label Step2Label;
    private System.Windows.Forms.Label Step3Label;
    private System.Windows.Forms.TextBox nTextBox;
    private System.Windows.Forms.TextBox qTextBox;
    private System.Windows.Forms.Label xLabel;
    private System.Windows.Forms.TextBox xTextBox;
    private System.Windows.Forms.Label nLabel;
    private System.Windows.Forms.GroupBox EncryptionGroupBox;
    private System.Windows.Forms.Label mLabel;
    private System.Windows.Forms.TextBox mTextBox;
    private System.Windows.Forms.Label Step6Label;
    private System.Windows.Forms.Label Step5Label;
    private System.Windows.Forms.Label MessageLabel;
    private System.Windows.Forms.TextBox MessageTextBox;
    private System.Windows.Forms.Label cLabel;
    private System.Windows.Forms.TextBox cTextBox;
    private System.Windows.Forms.GroupBox DecryptionGroupBox;
    private System.Windows.Forms.Label dMessageLabel;
    private System.Windows.Forms.TextBox dMessageTextBox;
    private System.Windows.Forms.Label Step7Label;
    private System.Windows.Forms.Label dMLabel;
    private System.Windows.Forms.TextBox dMTextBox;
    private System.Windows.Forms.Label rHintLabel;
    private System.Windows.Forms.Label cReceivedLabel;
    private System.Windows.Forms.TextBox cReceivedTextBox;

}
