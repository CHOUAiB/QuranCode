﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Drawing;
using System.ComponentModel;
using System.Windows.Forms;
using System.Threading;
using System.Reflection;
using System.Runtime.InteropServices;

public partial class NotifiableForm : Form, INotifiable
{
    private const string VERSION = "0.01";

    private Processor p_processor = null;
    private Thread m_worker_thread = null;

    public NotifiableForm()
    {
        InitializeComponent();
    }

    private void MainForm_Load(object sender, EventArgs e)
    {
        p_processor = null;
        m_worker_thread = null;
        this.AcceptButton = RunButton;
    }
    private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
    {
        if (m_worker_thread != null)
        {
            m_worker_thread.Join(); // wait for workerThread to terminate
            m_worker_thread = null;

            e.Cancel = false;
        }
    }
    private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
    {
        // never close Owner
        //this.Owner.Close();
    }
    private void MainForm_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Escape)
        {
            Cancel();
        }
        else
        {
            // do nothing
        }
    }

    private void EnableEntryControls()
    {
        m_old_progress = -1;
        ProgressLabel.Text = "Finished";
        ProgressLabel.Refresh();
        RunButton.Enabled = true;
        RunButton.Text = "Run";
        RunButton.Refresh();
        CloseButton.Text = "Close";
        CloseButton.Refresh();
    }
    private void DisableEntryControls()
    {
        ProgressLabel.Text = "Progress";
        ProgressLabel.Refresh();
        RunButton.Enabled = false;
        RunButton.Text = "Running ...";
        RunButton.Refresh();
        CloseButton.Text = "Cancel";
        CloseButton.Refresh();
    }
    private void ClearProgress()
    {
        ElapsedTimeValueLabel.Text = "00:00:00";
        ElapsedTimeValueLabel.Refresh();
        MilliSecondsLabel.Text = "000";
        MilliSecondsLabel.Refresh();
        ProgressBar.Value = 0;
        ProgressValueLabel.Text = ProgressBar.Value + "%";
        ProgressValueLabel.Refresh();
    }
    private void BeforeProcessing()
    {
        ClearProgress();
        DisableEntryControls();
    }
    private void AfterCancelled()
    {
        if (p_processor != null)
        {
            EnableEntryControls();
            ProgressLabel.Text = "Canceled";
            ProgressLabel.Refresh();
        }
    }
    private void AfterProcessing()
    {
        if (p_processor != null)
        {
            EnableEntryControls();
        }
    }

    public void Run()
    {
        if (
            (MessageTextBox.Text.Length > 0)
            &&
            (pTextBox.Text.Length > 0)
            &&
            (qTextBox.Text.Length > 0)
            )
        {
            BeforeProcessing();
            p_processor = new Processor(this, MessageTextBox.Text, pTextBox.Text, qTextBox.Text);
            if (p_processor != null)
            {
                m_worker_thread = new Thread(new ThreadStart(p_processor.Run));
                m_worker_thread.Priority = ThreadPriority.Lowest;
                m_worker_thread.IsBackground = true;
                m_worker_thread.Start();
            }
        }
    }
    public void Cancel()
    {
        if (p_processor != null)
        {
            p_processor.Cancel = true;
            if (m_worker_thread != null)
            {
                m_worker_thread.Join();
                m_worker_thread = null;
            }
        }
        AfterCancelled();
    }

    private int m_old_progress = -1;
    public void UpdateProgressMethod(int progress)
    {
        if (progress > m_old_progress)
        {
            m_old_progress = progress;
            if (p_processor != null)
            {
                if (p_processor.Cancel == false)
                {
                    if ((progress >= 0) && (progress <= 100))
                    {
                        ProgressBar.Value = progress;
                        ProgressValueLabel.Text = ProgressBar.Value + "%";
                        ProgressValueLabel.Refresh();

                        UpdateTimer(progress);
                    }

                    if (progress == 100) // finished naturally 
                    {
                        AfterProcessing();
                    }
                }
            }
        }
        else // no new progress
        {
            if (p_processor != null)
            {
                UpdateTimer(progress);
            }
        }
    }
    private void UpdateTimer(int progress)
    {
        TimeSpan timespan = p_processor.Duration;
        ElapsedTimeValueLabel.Text = String.Format("{0:00}:{1:00}:{2:00}", timespan.Hours, timespan.Minutes, timespan.Seconds);
        ElapsedTimeValueLabel.Refresh();
        MilliSecondsLabel.Text = String.Format("{0:000}", timespan.Milliseconds);
        MilliSecondsLabel.Refresh();
    }
    private StringBuilder str = new StringBuilder();  // define once outside function for perfomance reason
    public void UpdateResultMethod(List<object> result)
    {
        MessageTextBox.Text = result[0].ToString();
        nTextBox.Text = result[1].ToString();
        rTextBox.Text = result[2].ToString();
        eTextBox.Text = result[3].ToString();
        xTextBox.Text = result[4].ToString();
        yTextBox.Text = result[5].ToString();
        mTextBox.Text = result[6].ToString();
        cTextBox.Text = result[7].ToString();
        cReceivedTextBox.Text = result[7].ToString();
        dMTextBox.Text = result[8].ToString();
        dMessageTextBox.Text = result[9].ToString();
    }

    private void TextBox_TextChanged(object sender, EventArgs e)
    {
        if (
            (MessageTextBox.Text.Length == 0)
            ||
            (pTextBox.Text.Length == 0)
            ||
            (qTextBox.Text.Length == 0)
            )
        {
            nTextBox.Text = "";
            nTextBox.Refresh();
            rTextBox.Text = "";
            rTextBox.Refresh();
            eTextBox.Text = "";
            eTextBox.Refresh();
            xTextBox.Text = "";
            xTextBox.Refresh();
            yTextBox.Text = "";
            yTextBox.Refresh();
            mTextBox.Text = "";
            mTextBox.Refresh();
            cTextBox.Text = "";
            cTextBox.Refresh();
            cReceivedTextBox.Text = "";
            cReceivedTextBox.Refresh();
            dMTextBox.Text = "";
            dMTextBox.Refresh();
            dMessageTextBox.Text = "";
            dMessageTextBox.Refresh();
        }
    }

    private void RunButton_Click(object sender, EventArgs e)
    {
        if (pTextBox.Text == "")
        {
            pTextBox.Text = "1433";
            pTextBox.Refresh();
        }
        if (qTextBox.Text == "")
        {
            qTextBox.Text = "1439";
            qTextBox.Refresh();
        }
        if (MessageTextBox.Text == "")
        {
            MessageTextBox.Text = "God";
            MessageTextBox.Refresh();
        }

        Run();
    }
    private void CloseButton_Click(object sender, EventArgs e)
    {
        if (CloseButton.Text == "Cancel")
        {
            Cancel();
        }
        else
        {
            Close();
        }
    }
    private void ProgressBar_Click(object sender, EventArgs e)
    {
        try
        {
            System.Diagnostics.Process.Start("http://www.heliwave.com");
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, Application.ProductName);
        }
    }
}
